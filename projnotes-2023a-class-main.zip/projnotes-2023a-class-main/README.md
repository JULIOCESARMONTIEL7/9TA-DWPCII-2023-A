# projnotes-2023a-class
Class proyect from the FullStack web development
SubJect.

## About...
**Autor:** [Brayan Garcia]()
---
## Proyect Stack
This Proyect will be coded in ES6, as runtine
enviroment the project will use node, for the databases the proyect will use MongoDb Technology, for template engine we will use Handlebars

## Proyect Notes
1.[Proyect Creation](https://github.com/bryangc24/projnotes-2023a-class/tree/main)