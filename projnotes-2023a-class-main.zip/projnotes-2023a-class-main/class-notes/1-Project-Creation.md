# Project Creation

## Introduction
In this part of the proyect we created the 
repository on GitHub and then we opened a GitHub
Codespaces to modify and add new files to the project, the detailed steps of the process are described bellow.

## Methods
TODO: Student will write this part.
## Results
TODO: Student will write this part.
## Discussions
TODO: Student will write this part.
## Referencias
TODO: Student will write this part.